package com.jaehwan.jaehwanback;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JaehwanBackApplicationTests {

	@Test
	void contextLoads() {
	}

}
