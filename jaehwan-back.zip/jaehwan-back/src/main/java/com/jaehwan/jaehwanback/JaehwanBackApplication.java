package com.jaehwan.jaehwanback;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JaehwanBackApplication {

	public static void main(String[] args) {
		SpringApplication.run(JaehwanBackApplication.class, args);
	}

}
